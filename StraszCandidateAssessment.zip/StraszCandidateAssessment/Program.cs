﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Testlet.Library;

namespace StraszCandidateAssessment
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Item> listAllQuestions = new List<Item>() {
                new Item{ItemId="5",ItemType= ItemTypeEnum.Operational},
                new Item{ItemId="2",ItemType= ItemTypeEnum.Pretest},
                new Item{ItemId="4",ItemType= ItemTypeEnum.Pretest},
                new Item{ItemId="6",ItemType= ItemTypeEnum.Operational},
                new Item{ItemId="7",ItemType= ItemTypeEnum.Operational},
                new Item{ItemId="8",ItemType= ItemTypeEnum.Operational},
                new Item{ItemId="3",ItemType= ItemTypeEnum.Pretest},
                new Item{ItemId="9",ItemType= ItemTypeEnum.Operational},
                new Item{ItemId="1",ItemType= ItemTypeEnum.Pretest},
                new Item{ItemId="10",ItemType= ItemTypeEnum.Operational}
            };

            Testlet.Library.Testlet inputTestlet = new Testlet.Library.Testlet("1", listAllQuestions);
            List<Item> listRandomItems = new List<Item>();

            listRandomItems = inputTestlet.Randomize();

            if (listRandomItems != null)
            {
                foreach (var item in listRandomItems)
                {
                    Console.WriteLine("Question ID: " + item.ItemId + ", Question Type: " + item.ItemType);
                }
            }
            else
            {
                Console.WriteLine("No Questions were loaded.");
            }

            Console.ReadLine();
        }
    }
}
