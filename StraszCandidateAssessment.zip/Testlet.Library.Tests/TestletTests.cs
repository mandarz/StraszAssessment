﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testlet.Library.Tests
{
    [TestFixture]
    public class TestletTests
    {
        List<Item> listAllItems = new List<Item>() {
                new Item{ItemId="5",ItemType= ItemTypeEnum.Operational},
                new Item{ItemId="2",ItemType= ItemTypeEnum.Pretest},
                new Item{ItemId="4",ItemType= ItemTypeEnum.Pretest},
                new Item{ItemId="6",ItemType= ItemTypeEnum.Operational},
                new Item{ItemId="7",ItemType= ItemTypeEnum.Operational},
                new Item{ItemId="8",ItemType= ItemTypeEnum.Operational},
                new Item{ItemId="3",ItemType= ItemTypeEnum.Pretest},
                new Item{ItemId="9",ItemType= ItemTypeEnum.Operational},
                new Item{ItemId="1",ItemType= ItemTypeEnum.Pretest},
                new Item{ItemId="10",ItemType= ItemTypeEnum.Operational}
            };

        [Test]
        public void Test1_Checks_If_First_Item_Is_Pretest_And_Randomly_Selected()
        {
            // The first 2 items are always pretest items selected randomly from the 4 pretest items.
            // Arrange
            Testlet inputTestlet = new Testlet("1", listAllItems);

            // Act
            List<Item> listRandomItems = new List<Item>();
            bool isRandom = false;

            List<Item> listOriginalItems = new List<Item>();
            foreach (var item in listAllItems)
            {
                listOriginalItems.Add(item);
            }

            listRandomItems = inputTestlet.Randomize();

            // Check if the items are randomized
            for (int i = 0; i < listRandomItems.Count; i++)
            {
                if (listRandomItems[i] != listOriginalItems[i])
                {
                    isRandom = true;
                }
            }

            // Assert
            Assert.AreEqual(listRandomItems[0].ItemType, ItemTypeEnum.Pretest);
            if (isRandom == false)
            {
                Assert.Fail();
            }
        }

        [Test]
        public void Test2_Checks_If_Second_Item_Is_Pretest_And_Randomly_Selected()
        {
            // The first 2 items are always pretest items selected randomly from the 4 pretest items.
            // Arrange
            Testlet inputTestlet = new Testlet("1", listAllItems);

            // Act
            List<Item> listRandomItems = new List<Item>();
            bool isRandom = false;

            List<Item> listOriginalItems = new List<Item>();
            foreach (var item in listAllItems)
            {
                listOriginalItems.Add(item);
            }

            listRandomItems = inputTestlet.Randomize();

            // Check if the items are randomized
            for (int i = 0; i < listRandomItems.Count; i++)
            {
                if (listRandomItems[i] != listOriginalItems[i])
                {
                    isRandom = true;
                }
            }

            // Assert
            Assert.AreEqual(listRandomItems[1].ItemType, ItemTypeEnum.Pretest);
            if (isRandom == false)
            {
                Assert.Fail();
            }
        }

        [Test]
        public void Test3_Checks_If_Remaining_Items_Have_2_Pretest_And_6_Operational_Types()
        {
            // REQUIREMENT: The next 8 items are mix of pretest and operational items
            // ordered randomly from the remaining 8 items.

            // Arrange
            Testlet inputTestlet = new Testlet("1", listAllItems);

            // Act
            List<Item> listRandomItems = new List<Item>();

            List<Item> listOriginalItems = new List<Item>();
            foreach (var item in listAllItems)
            {
                listOriginalItems.Add(item);
            }

            listRandomItems = inputTestlet.Randomize();

            // Assert

            // Check if the items are randomized
            bool isRandom = false;
            for (int i = 0; i < listRandomItems.Count; i++)
            {
                if (listRandomItems[i] != listOriginalItems[i])
                {
                    isRandom = true;
                }
            }

            // Check if there are 2 pretest and 6 operational items
            int countPretest = 0;
            int countOperational = 0;

            for (int i = 2; i < listRandomItems.Count; i++)
            {
                if (listRandomItems[i].ItemType == ItemTypeEnum.Pretest)
                {
                    countPretest += 1;
                }
                else
                {
                    countOperational += 1;
                }
            }

            Assert.AreEqual(countPretest, 2);
            Assert.AreEqual(countOperational, 6);
        }
    }
}
