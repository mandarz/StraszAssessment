﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testlet.Library
{
    public class Testlet
    {
        public string TestletId;
        private List<Item> Items;

        public Testlet(string testletId, List<Item> items)
        {
            TestletId = testletId;
            Items = items;
        }

        public List<Item> Randomize()
        {
            // Items private collection has 6 Operational and 4 Pretest Items.
            // Randomize the order of these items as per the requirement(with TDD)

            if (Items == null || Items.Count == 0)
            {
                return null;
            }

            List<Item> PretestItems = new List<Item>();
            List<Item> OperationalItems = new List<Item>();
            Random rnd = new Random();

            foreach (var item in Items)
            {
                // Check if the item type is pretest and add it to the Pretest Items List
                if (item.ItemType == ItemTypeEnum.Pretest)
                {
                    PretestItems.Add(item);
                }
                else
                {
                    // Else add it to the Operational Items List
                    OperationalItems.Add(item);
                }
            }

            //Randomize the Pretest Items List
            PretestItems = PretestItems.OrderBy(rdm => rnd.Next()).ToList();

            //Clear the Items collection
            Items.Clear();

            foreach (var item in PretestItems)
            {
                // Add the first two Random Pretest Items to the Items list
                if (Items.Count <= 1)
                {
                    Items.Add(item);
                }
                else
                {
                    // Add the remaining Random Pretest Items to the Items list
                    OperationalItems.Add(item);
                }
            }

            // Randomize the Operational Items List which has 2 Pretest and 6 Operational Items
            OperationalItems = OperationalItems.OrderBy(rdm => rnd.Next()).ToList();

            // Add the remaining Random Operational Items to the Items list
            foreach (var item in OperationalItems)
            {
                Items.Add(item);
            }

            // Return the Items list formed
            return Items;
        }
    }

    public class Item
    {
        public string ItemId;
        public ItemTypeEnum ItemType;
    }

    public enum ItemTypeEnum
    {
        Pretest = 0,
        Operational = 1
    }
}
